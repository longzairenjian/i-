package com.onemo.sss.interceptor;

import com.onemo.sss.pojo.LoginUser;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Objects;

@Component
public class LoginInterceptor implements HandlerInterceptor {


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HttpSession session = request.getSession();
        LoginUser userInfo = (LoginUser) session.getAttribute("userInfo");
        if (Objects.isNull(userInfo) || "".equals(userInfo.getUsername())) {
            //不符合条件的给出提示信息，并转发到登录页面
            request.setAttribute("msg", "您还没有登录，请先登录！");
            response.sendRedirect(request.getContextPath() + "/");
            return false;
        }
        return true;
    }

}
