package com.onemo.sss.controller;

import com.onemo.sss.pojo.LoginUser;
import com.onemo.sss.pojo.Result;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
public class LoginController {

    @RequestMapping("/")
    public String index() {
        return "index";
    }

    @RequestMapping("login")
    @ResponseBody
    public Result login(HttpServletRequest req, HttpServletResponse resp, @RequestParam String username, @RequestParam String password) {
        Result result = new Result();
        //获取session
        HttpSession session = req.getSession();
        if ("admin".equals(username) && "admin".equals(password)) {
            session.setAttribute("userInfo", new LoginUser(username,password));
            result.setStatus("200");
        } else {
            result.setStatus("500");
            result.setMessage("用户名或者密码不正确");
        }
        return result;
    }
}

