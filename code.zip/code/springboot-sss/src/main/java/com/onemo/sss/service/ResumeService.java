package com.onemo.sss.service;


import com.onemo.sss.pojo.Resume;

import java.util.List;

public interface ResumeService {

    void save(Resume resume);


    void delete(Long id);


    List<Resume> findAll();

    Resume findById(Long id);

}
