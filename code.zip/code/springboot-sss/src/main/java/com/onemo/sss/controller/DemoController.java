package com.onemo.sss.controller;

import com.onemo.sss.pojo.Result;
import com.onemo.sss.pojo.Resume;
import com.onemo.sss.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("demo")
public class DemoController {

    @Autowired
    private ResumeService resumeService;

    @RequestMapping("list")
    public ModelAndView list() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("list", resumeService.findAll());
        modelAndView.setViewName("list");
        return modelAndView;
    }

    @RequestMapping("update/{id}")
    public ModelAndView update(@PathVariable Long id) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("resume", resumeService.findById(id));
        modelAndView.setViewName("update");
        return modelAndView;
    }

    @RequestMapping("add")
    public String add() {
        return "update";
    }

    @RequestMapping("save")
    @ResponseBody
    public Result save(@RequestBody Resume resume) {
        resumeService.save(resume);
        Result result = new Result();
        result.setStatus("200");
        return result;
    }

    @RequestMapping("delete/{id}")
    @ResponseBody
    public Result list(@PathVariable Long id) {
        resumeService.delete(id);
        Result result = new Result();
        result.setStatus("200");
        return result;
    }


}
